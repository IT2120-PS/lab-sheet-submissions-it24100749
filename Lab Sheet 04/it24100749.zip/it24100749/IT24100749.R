setwd("C:\\Users\\it24100749\\Desktop\\it24100749")
branch_data <- read.table("Exercise.txt",header=TRUE, sep=",")
fix(branch_data)

str(branch_data)

boxplot(branch_data$sales, 
        main="Boxplot of sales",
        ylab = "sales amount",
        outline = TRUE, 
        horizontal = FALSE)


advertising_summary <- summary(branch_data$Advertising)
print(advertising_summary)

advertising_iqr <- IQR(branch_data$Advertising)
print(paste("IQR for advertising:",advertising_iqr))

find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  
  outliers <- x[x < lower_bound | x > upper_bound]
  
  if (length(outliers) == 0) {
    return("No outliers detected")
  } else {
    return(sort(outliers))
  }
}

# Check for outliers in Years variable
years_outliers <- find_outliers(branch_data$Years)
print(paste("Outliers in Years variable:", paste(years_outliers, collapse=", ")))







